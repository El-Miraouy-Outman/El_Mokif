package com.example.maalm.controller;

import com.example.maalm.entities.Publication;
import com.example.maalm.service.PublicationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/publications")
public class PublicationController {
    private final  PublicationService publicationService;
    @GetMapping("/maalm/{idMaalm}")
    public List<Publication> findByMaalm(@PathVariable Long idMaalm) throws Exception {
        return publicationService.findByMaalm(idMaalm);
    }

    @GetMapping("/{IDPUB}")
    public Publication findById(@PathVariable Long IDPUB) {
        return publicationService.findById(IDPUB);
    }

    @DeleteMapping("/{IDPUB}")
    public Publication deleteById(Long IDPUB) {
        return publicationService.deleteById(IDPUB);
    }

    @PostMapping("/service/{idPublicateur}/publicateur/{serviceName}")
    public Publication insert(Publication publication, Long idPublicateur, String servicaName) throws Exception {
        return null;
    }
}
