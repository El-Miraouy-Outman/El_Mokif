package com.example.maalm.service;

import com.example.maalm.entities.Maalm;
import com.example.maalm.entities.Publication;
import com.example.maalm.repository.PublicationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;


@Service
@RequiredArgsConstructor
public class PublicationServiceImpl implements PublicationService {
    private final PublicationRepository publicationRepository;
    private final MaalmService maalmService;
    private final ServiceService serviceService;

    @Override
    public List<Publication> findByMaalm(Long idMamm) throws Exception {
        Maalm maalm=maalmService.findById(idMamm);
        List<Publication> listePub=publicationRepository.findByMaalm(maalm);
        return listePub;
    }

    @Override
    public Publication findById(Long IDPUB) {
        return null;
    }

    @Override
    public Publication deleteById(Long IDPUB) {
        return null;
    }


    @Override
    public Publication insert(Publication publication, Long idPublicateur, String servicaName) throws Exception {
        Maalm maalm = maalmService.findById(idPublicateur);
        com.example.maalm.entities.Service service=serviceService.getServiceByName(servicaName);
        publication.setDatecreation(new Date());
        publication.setService(service);
        publication.setMaalm(maalm);
        //List<Publication> publicationList = new ArrayList<>();
        //publicationList.addAll(maalm.getPublication());
        //System.out.println(publicationList);
        return publicationRepository.save(publication);
    }
}
