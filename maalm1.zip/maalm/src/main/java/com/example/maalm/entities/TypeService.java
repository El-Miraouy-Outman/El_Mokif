package com.example.maalm.entities;

public enum TypeService {
    OFFRE,DEMMANDE
}
