package com.example.maalm.service;

import com.example.maalm.entities.Publication;

import java.util.List;

public interface PublicationService {
    public List<Publication> findByMaalm(Long idMamm) throws Exception;
    public Publication findById(Long IDPUB);
    public Publication deleteById(Long IDPUB);
    public Publication insert(Publication publication,Long IdPublicateur,String servicaName) throws Exception;


}
